# Data Directory Overview

This directory contains the public empirical datasets used to parameterize and validate the computational model:

- `raw/hpa_tissue_ntpm.csv`: Cross-regional transcriptomic abundances (nTPM) from The Human Protein Atlas (HPA v23, tissue dataset) for *SCN1A*, *SCN2A*, *SCN8A*, *GABRA2*, *GABRB2*, and *CACNA1G* across cerebral cortex, thalamus, hippocampus, and cerebellum.
- `raw/hpa_singlecell_ncpm.csv`: Single-cell resolution transcriptomic abundances (nCPM) from HPA scRNA-seq brain dataset across excitatory pyramidal neurons, inhibitory interneurons, astrocytes, and oligodendrocytes.
- `raw/brainspan_developmental_rpkm.csv`: Ontogenetic developmental series (RPKM) from the BrainSpan Atlas of the Developing Human Brain from 8 post-conceptional weeks (pcw) to adult life.
- `raw/modifier_strains_gabra2_cacna1g.csv`: Empirical expression ratios of *Gabra2* and *Cacna1g* across C57BL/6J, F1 hybrids, and 129S6/SvEv mouse strains.
- `raw/biophysical_parameters.csv`: Full biophysical reference parameters calibrated against whole-cell patch-clamp literature.
- `checksums.sha256`: Cryptographic SHA-256 hashes verifying file integrity.
