#!/usr/bin/env python3
"""
01_biophysical_model.py - Single-cell Hodgkin-Huxley simulation and action potential analysis.
Validates baseline firing rates and electrophysiological dynamics of WT, GOF, and LOF channels.
"""

import os
import sys
import numpy as np

# Add code directory to path
sys.path.insert(0, os.path.dirname(__file__))
from biophys import (
    simulate_neuron, find_rheobase,
    V_HALF_ACT_WT, K_ACT_WT, V_HALF_INACT_WT, K_INACT_WT,
    F_NAP_WT, G_NA_BAR
)


def main():
    print("=" * 70)
    print(" Step 01: Single-Cell Biophysical Simulation & Action Potential Gating")
    print("=" * 70)

    # 1. Simulate Wild-Type Neuron
    print("\n[1] Simulating Wild-Type NaV1.2 Pyramidal Baseline:")
    t_wt, V_wt, f_wt = simulate_neuron(
        duration=500.0, I_inj=15.0,
        V_half_act=V_HALF_ACT_WT, k_act=K_ACT_WT,
        V_half_inact=V_HALF_INACT_WT, k_inact=K_INACT_WT,
        f_NaP=F_NAP_WT
    )
    rheo_wt = find_rheobase(
        V_half_act=V_HALF_ACT_WT, k_act=K_ACT_WT,
        V_half_inact=V_HALF_INACT_WT, k_inact=K_INACT_WT,
        f_NaP=F_NAP_WT
    )
    print(f"  WT Firing Frequency at 15 uA/cm^2: {f_wt:.2f} Hz")
    print(f"  WT Rheobase Current: {rheo_wt:.2f} uA/cm^2")

    # 2. Simulate Gain-of-Function (Severe GOF: dV = -10 mV, f_NaP = 10%)
    print("\n[2] Simulating Severe SCN2A Gain-of-Function Mutation (GOF-3):")
    t_gof, V_gof, f_gof = simulate_neuron(
        duration=500.0, I_inj=15.0,
        V_half_act=V_HALF_ACT_WT - 10.0, k_act=K_ACT_WT,
        V_half_inact=V_HALF_INACT_WT, k_inact=K_INACT_WT,
        f_NaP=0.10
    )
    rheo_gof = find_rheobase(
        V_half_act=V_HALF_ACT_WT - 10.0, k_act=K_ACT_WT,
        V_half_inact=V_HALF_INACT_WT, k_inact=K_INACT_WT,
        f_NaP=0.10
    )
    print(f"  GOF-3 Firing Frequency at 15 uA/cm^2: {f_gof:.2f} Hz")
    print(f"  GOF-3 Rheobase Current: {rheo_gof:.2f} uA/cm^2")
    print(f"  Frequency Shift: +{((f_gof - f_wt)/f_wt)*100:.1f}%")
    print(f"  Rheobase Shift: -{((rheo_wt - rheo_gof)/rheo_wt)*100:.1f}%")

    # 3. Simulate Loss-of-Function (Haploinsufficiency: g_Na * 0.5)
    print("\n[3] Simulating SCN2A Loss-of-Function Haploinsufficiency (LOF-1):")
    t_lof, V_lof, f_lof = simulate_neuron(
        g_Na=G_NA_BAR * 0.50,
        duration=500.0, I_inj=15.0,
        V_half_act=V_HALF_ACT_WT, k_act=K_ACT_WT,
        V_half_inact=V_HALF_INACT_WT, k_inact=K_INACT_WT,
        f_NaP=F_NAP_WT
    )
    rheo_lof = find_rheobase(
        g_Na=G_NA_BAR * 0.50,
        V_half_act=V_HALF_ACT_WT, k_act=K_ACT_WT,
        V_half_inact=V_HALF_INACT_WT, k_inact=K_INACT_WT,
        f_NaP=F_NAP_WT
    )
    print(f"  LOF-1 Firing Frequency at 15 uA/cm^2: {f_lof:.2f} Hz")
    print(f"  LOF-1 Rheobase Current: {rheo_lof:.2f} uA/cm^2")
    print(f"  Frequency Shift: {((f_lof - f_wt)/f_wt)*100:.1f}%")
    print(f"  Rheobase Shift: +{((rheo_lof - rheo_wt)/rheo_wt)*100:.1f}%")

    print("\n[OK] Single-cell biophysical model initialized and verified.")


if __name__ == '__main__':
    main()
