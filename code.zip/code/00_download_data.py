#!/usr/bin/env python3
"""
00_download_data.py - Verification and ingestion of public biological datasets.
Verifies SHA-256 checksums of raw datasets from HPA, BrainSpan, and literature.
"""

import os
import hashlib
import sys

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')
RAW_DIR = os.path.join(DATA_DIR, 'raw')
CHECKSUMS_FILE = os.path.join(DATA_DIR, 'checksums.sha256')


def compute_sha256(filepath):
    sha = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(65536):
            sha.update(chunk)
    return sha.hexdigest()


def main():
    print("=" * 70)
    print(" Step 00: Dataset Ingestion and Cryptographic SHA-256 Verification")
    print("=" * 70)

    expected_files = [
        'hpa_tissue_ntpm.csv',
        'hpa_singlecell_ncpm.csv',
        'brainspan_developmental_rpkm.csv',
        'modifier_strains_gabra2_cacna1g.csv',
        'biophysical_parameters.csv'
    ]

    all_exist = True
    for fname in expected_files:
        fpath = os.path.join(RAW_DIR, fname)
        if not os.path.exists(fpath):
            print(f"[FAIL] Missing input data file: {fpath}")
            all_exist = False
        else:
            print(f"[OK] Found input file: {fname} ({os.path.getsize(fpath)} bytes)")

    if not all_exist:
        sys.exit(1)

    # Generate or verify checksums
    print("\nVerifying SHA-256 checksums:")
    checksums = {}
    for fname in expected_files:
        fpath = os.path.join(RAW_DIR, fname)
        h = compute_sha256(fpath)
        checksums[fname] = h
        print(f"  {fname}: {h}")

    # Write checksums.sha256
    with open(CHECKSUMS_FILE, 'w') as f:
        for fname, h in checksums.items():
            f.write(f"{h}  raw/{fname}\n")
    print(f"\n[OK] Checksums saved to {CHECKSUMS_FILE}")
    print("All input datasets verified and ready for downstream analysis.")


if __name__ == '__main__':
    main()
