#!/usr/bin/env python3
"""
02_stoichiometry_and_expression.py - Stoichiometric normalization and regional/cell-type expression profiling.
Reproduces Table 1 and Table 4 of the manuscript.
"""

import os
import sys
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from biophys import G_NA_BAR, WEIGHTS_EXC, WEIGHTS_INH

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')
RAW_DIR = os.path.join(DATA_DIR, 'raw')
RESULTS_DIR = os.path.join(os.path.dirname(__file__), '..', 'results')
os.makedirs(RESULTS_DIR, exist_ok=True)

E_REF_TISSUE = 60.0  # nTPM reference ceiling
E_REF_SC = 400.0     # nCPM reference ceiling


def main():
    print("=" * 70)
    print(" Step 02: Stoichiometric Normalization across Regions and Cell Types")
    print("=" * 70)

    # 1. Regional Tissue Profiling (Table 1)
    tissue_file = os.path.join(RAW_DIR, 'hpa_tissue_ntpm.csv')
    df_tissue = pd.read_csv(tissue_file)

    df_tissue['SCN1A_Enorm'] = (df_tissue['SCN1A_mean'] / E_REF_TISSUE).round(3)
    df_tissue['SCN2A_Enorm'] = (df_tissue['SCN2A_mean'] / E_REF_TISSUE).round(3)
    df_tissue['SCN8A_Enorm'] = (df_tissue['SCN8A_mean'] / E_REF_TISSUE).round(3)
    df_tissue['Total_NaV_nTPM'] = (df_tissue['SCN1A_mean'] + df_tissue['SCN2A_mean'] + df_tissue['SCN8A_mean']).round(1)

    t1_cols = [
        'Region', 'SCN1A_mean', 'SCN1A_min', 'SCN1A_max', 'SCN1A_Enorm',
        'SCN2A_mean', 'SCN2A_min', 'SCN2A_max', 'SCN2A_Enorm',
        'SCN8A_mean', 'SCN8A_min', 'SCN8A_max', 'SCN8A_Enorm', 'Total_NaV_nTPM'
    ]
    df_t1 = df_tissue[t1_cols]
    t1_path = os.path.join(RESULTS_DIR, 'Table1_regional_expression.tsv')
    df_t1.to_csv(t1_path, sep='\t', index=False)
    print(f"\n[OK] Table 1 saved to: {t1_path}")
    print(df_t1[['Region', 'SCN1A_Enorm', 'SCN2A_Enorm', 'SCN8A_Enorm', 'Total_NaV_nTPM']].to_string(index=False))

    # 2. Single-Cell Profiling (Table 4)
    sc_file = os.path.join(RAW_DIR, 'hpa_singlecell_ncpm.csv')
    df_sc = pd.read_csv(sc_file)

    df_sc['SCN1A_Enorm'] = df_sc['SCN1A_nCPM'] / E_REF_SC
    df_sc['SCN2A_Enorm'] = df_sc['SCN2A_nCPM'] / E_REF_SC
    df_sc['SCN8A_Enorm'] = df_sc['SCN8A_nCPM'] / E_REF_SC

    # Compute effective conductances
    conductances = []
    for _, row in df_sc.iterrows():
        ctype = row['CellType']
        if 'Excitatory' in ctype:
            w = WEIGHTS_EXC
        elif 'Inhibitory' in ctype:
            w = WEIGHTS_INH
        else:
            w = {'SCN1A': 0.333, 'SCN2A': 0.333, 'SCN8A': 0.333}
        
        g_eff = G_NA_BAR * (w['SCN1A'] * row['SCN1A_Enorm'] +
                            w['SCN2A'] * row['SCN2A_Enorm'] +
                            w['SCN8A'] * row['SCN8A_Enorm'])
        conductances.append(round(g_eff, 2))

    df_sc['g_Na_eff_mS_cm2'] = conductances
    t4_path = os.path.join(RESULTS_DIR, 'Table4_single_cell_excitability.tsv')
    df_sc.to_csv(t4_path, sep='\t', index=False)
    print(f"\n[OK] Table 4 saved to: {t4_path}")
    print(df_sc[['CellType', 'SCN1A_nCPM', 'SCN2A_nCPM', 'SCN8A_nCPM', 'g_Na_eff_mS_cm2']].to_string(index=False))


if __name__ == '__main__':
    main()
