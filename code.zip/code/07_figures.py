#!/usr/bin/env python3
"""
07_figures.py - Generates all publication-quality vector (PDF) and raster (300/600 dpi PNG) figures.
Figures 1-5 and Figure S1.
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

sys.path.insert(0, os.path.dirname(__file__))
from biophys import (
    simulate_neuron, boltzmann_act, boltzmann_inact, boltzmann_p,
    V_HALF_ACT_WT, K_ACT_WT, V_HALF_INACT_WT, K_INACT_WT
)

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data', 'raw')
RESULTS_DIR = os.path.join(os.path.dirname(__file__), '..', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(__file__), '..', 'figures')
os.makedirs(FIGURES_DIR, exist_ok=True)


def set_nature_style():
    """Sets publication style adhering to Nature guidelines."""
    plt.rcParams.update({
        'font.family': 'sans-serif',
        'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
        'font.size': 8,
        'axes.labelsize': 9,
        'axes.titlesize': 10,
        'xtick.labelsize': 8,
        'ytick.labelsize': 8,
        'legend.fontsize': 7.5,
        'figure.titlesize': 11,
        'lines.linewidth': 1.2,
        'axes.linewidth': 0.8,
        'xtick.major.width': 0.8,
        'ytick.major.width': 0.8,
        'axes.spines.top': False,
        'axes.spines.right': False,
        'savefig.bbox': 'tight',
        'savefig.pad_inches': 0.05
    })


def save_figure(fig, base_name):
    """Saves figure in both high-res PDF (vector) and 300-dpi PNG (raster)."""
    pdf_path = os.path.join(FIGURES_DIR, f"{base_name}.pdf")
    png_path = os.path.join(FIGURES_DIR, f"{base_name}.png")
    fig.savefig(pdf_path, format='pdf')
    fig.savefig(png_path, format='png', dpi=300)
    plt.close(fig)
    print(f"  Saved: {base_name}.pdf and {base_name}.png")


def generate_figure1():
    """Figure 1: Regional Stoichiometric Availability."""
    df_tissue = pd.read_csv(os.path.join(DATA_DIR, 'hpa_tissue_ntpm.csv'))

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.2))

    # Panel A: Absolute Expression
    regions = df_tissue['Region']
    x = np.arange(len(regions))
    w = 0.25

    colors = ['#2b5c8f', '#2a9d8f', '#e76f51']
    genes = ['SCN1A', 'SCN2A', 'SCN8A']

    for i, g in enumerate(genes):
        mean_col = f"{g}_mean"
        min_col = f"{g}_min"
        max_col = f"{g}_max"
        y = df_tissue[mean_col]
        yerr = [y - df_tissue[min_col], df_tissue[max_col] - y]
        ax1.bar(x + (i - 1) * w, y, width=w, yerr=yerr, capsize=3,
                label=g, color=colors[i], alpha=0.9, edgecolor='black', lw=0.6)

    ax1.set_xticks(x)
    ax1.set_xticklabels(regions, rotation=15, ha='right')
    ax1.set_ylabel('Transcript Abundance (nTPM)')
    ax1.set_title('A. Regional NaV Abundance (HPA v23)', fontweight='bold')
    ax1.legend(frameon=True, facecolor='white', framealpha=0.9)

    # Panel B: Fractional Stoichiometric Contribution
    totals = df_tissue['SCN1A_mean'] + df_tissue['SCN2A_mean'] + df_tissue['SCN8A_mean']
    f_1A = df_tissue['SCN1A_mean'] / totals
    f_2A = df_tissue['SCN2A_mean'] / totals
    f_8A = df_tissue['SCN8A_mean'] / totals

    ax2.bar(regions, f_1A, label='SCN1A (NaV1.1)', color=colors[0], edgecolor='black', lw=0.6)
    ax2.bar(regions, f_2A, bottom=f_1A, label='SCN2A (NaV1.2)', color=colors[1], edgecolor='black', lw=0.6)
    ax2.bar(regions, f_8A, bottom=f_1A + f_2A, label='SCN8A (NaV1.6)', color=colors[2], edgecolor='black', lw=0.6)

    ax2.set_xticklabels(regions, rotation=15, ha='right')
    ax2.set_ylabel('Subunit Fraction of Total NaV')
    ax2.set_title('B. Subunit Stoichiometry Composition', fontweight='bold')
    ax2.legend(loc='lower right', frameon=True, facecolor='white', framealpha=0.9)

    fig.tight_layout()
    save_figure(fig, 'Figure1')


def generate_figure2():
    """Figure 2: Electrophysiological consequences of SCN2A mutations."""
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.6))

    # Simulate traces
    t_wt, v_wt, _ = simulate_neuron(duration=150.0, I_inj=15.0)
    t_gof, v_gof, _ = simulate_neuron(
        duration=150.0, I_inj=15.0,
        V_half_act=V_HALF_ACT_WT - 10.0, f_NaP=0.10
    )
    t_lof, v_lof, _ = simulate_neuron(
        duration=150.0, I_inj=15.0,
        g_Na=60.0
    )

    # Panel A: Pyramidal AP train
    axes[0].plot(t_wt, v_wt, 'k--', label='WT (38.5 Hz)', lw=1.0)
    axes[0].plot(t_gof, v_gof, '#d90429', label='GOF-3 (61.8 Hz)', lw=1.0)
    axes[0].set_xlim(0, 150)
    axes[0].set_ylim(-85, 55)
    axes[0].set_xlabel('Time (ms)')
    axes[0].set_ylabel('Membrane Potential (mV)')
    axes[0].set_title('A. Pyramidal AP: WT vs GOF', fontweight='bold')
    axes[0].legend(loc='upper right')

    # Panel B: Pyramidal AP train WT vs LOF
    axes[1].plot(t_wt, v_wt, 'k--', label='WT (38.5 Hz)', lw=1.0)
    axes[1].plot(t_lof, v_lof, '#0077b6', label='LOF-1 (34.4 Hz)', lw=1.0)
    axes[1].set_xlim(0, 150)
    axes[1].set_ylim(-85, 55)
    axes[1].set_xlabel('Time (ms)')
    axes[1].set_ylabel('Membrane Potential (mV)')
    axes[1].set_title('B. Pyramidal AP: WT vs LOF', fontweight='bold')
    axes[1].legend(loc='upper right')

    # Panel C: F-I curves
    inj_currents = np.linspace(2.0, 20.0, 10)
    f_wt_curve = [simulate_neuron(I_inj=i, duration=200.0)[2] for i in inj_currents]
    f_gof_curve = [simulate_neuron(I_inj=i, duration=200.0, V_half_act=V_HALF_ACT_WT - 10.0, f_NaP=0.10)[2] for i in inj_currents]
    f_lof_curve = [simulate_neuron(I_inj=i, duration=200.0, g_Na=60.0)[2] for i in inj_currents]

    axes[2].plot(inj_currents, f_gof_curve, 'o-', color='#d90429', label='GOF-3 (DEE)', markersize=3)
    axes[2].plot(inj_currents, f_wt_curve, 's--', color='black', label='WT Baseline', markersize=3)
    axes[2].plot(inj_currents, f_lof_curve, '^-', color='#0077b6', label='LOF-1 (ASD)', markersize=3)
    axes[2].set_xlabel('Current Injection (uA/cm^2)')
    axes[2].set_ylabel('Firing Rate (Hz)')
    axes[2].set_title('C. F-I Curves', fontweight='bold')
    axes[2].legend(loc='lower right')

    fig.tight_layout()
    save_figure(fig, 'Figure2')


def generate_figure3():
    """Figure 3: 2D Parametric Landscape of PDI."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.2))

    # Read Table 3 data
    t3_file = os.path.join(RESULTS_DIR, 'Table3_2d_parametric_landscape_pdi.tsv')
    df_t3 = pd.read_csv(t3_file, sep='\t')

    pdi_matrix = df_t3.drop(columns=['Activation_Shift_mV']).values
    f_labels = ['1% (WT)', '3% (Mild)', '6% (Mod)', '10% (High)', '14% (Ext)']
    dv_labels = [f"{v:+.1f} mV" for v in df_t3['Activation_Shift_mV']]

    # Panel A: Heatmap
    sns.heatmap(pdi_matrix, ax=ax1, cmap='coolwarm', center=0, vmin=-0.40, vmax=+0.50,
                annot=True, fmt='.3f', annot_kws={'size': 7},
                xticklabels=f_labels, yticklabels=dv_labels,
                cbar_kws={'label': 'Phenotypic Divergence Index (PDI)'})
    ax1.set_xlabel('Persistent Sodium Current Fraction (f_NaP)')
    ax1.set_ylabel('Activation Voltage Shift (dV_1/2,act)')
    ax1.set_title('A. PDI Landscape (Autism vs DEE)', fontweight='bold')

    # Panel B: Cross-sectional curves showing inversion of LOF to DEE
    f_vals = [0.01, 0.03, 0.06, 0.10, 0.14]
    ax2.plot(f_vals, pdi_matrix[0], 'o-', color='#b7094c', label='-12 mV (Extreme GOF)', markersize=4)
    ax2.plot(f_vals, pdi_matrix[1], 's-', color='#e36414', label='-8 mV (Severe GOF)', markersize=4)
    ax2.plot(f_vals, pdi_matrix[3], 'k--', label='0 mV (WT gating)', lw=1.2)
    ax2.plot(f_vals, pdi_matrix[4], '^-', color='#0096c7', label='+4 mV (Mild LOF)', markersize=4)
    ax2.plot(f_vals, pdi_matrix[5], 'd-', color='#03045e', label='+8 mV (Severe LOF)', markersize=4)

    ax2.axhline(0.15, color='red', linestyle=':', lw=1.0, label='Seizure Threshold (+0.15)')
    ax2.axhline(-0.15, color='blue', linestyle=':', lw=1.0, label='ASD Threshold (-0.15)')
    ax2.axhline(0.00, color='gray', linestyle='-', lw=0.6)

    ax2.set_xlabel('Persistent Current Fraction (f_NaP)')
    ax2.set_ylabel('Circuit PDI Score')
    ax2.set_title('B. LOF Inversion by Persistent Currents', fontweight='bold')
    ax2.legend(loc='lower right', fontsize=6.5)

    fig.tight_layout()
    save_figure(fig, 'Figure3')


def generate_figure4():
    """Figure 4: Single-Cell Lineage Segregation."""
    df_sc = pd.read_csv(os.path.join(DATA_DIR, 'hpa_singlecell_ncpm.csv'))

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.2))

    # Panel A: scRNA-seq expression
    cell_types = df_sc['CellType']
    x = np.arange(len(cell_types))
    w = 0.25
    colors = ['#2b5c8f', '#2a9d8f', '#e76f51']

    ax1.bar(x - w, df_sc['SCN1A_nCPM'], width=w, label='SCN1A (NaV1.1)', color=colors[0], edgecolor='black', lw=0.6)
    ax1.bar(x, df_sc['SCN2A_nCPM'], width=w, label='SCN2A (NaV1.2)', color=colors[1], edgecolor='black', lw=0.6)
    ax1.bar(x + w, df_sc['SCN8A_nCPM'], width=w, label='SCN8A (NaV1.6)', color=colors[2], edgecolor='black', lw=0.6)

    ax1.set_xticks(x)
    ax1.set_xticklabels(['Excitatory', 'Inhibitory', 'Astrocytes', 'Oligodendrocytes'], rotation=15, ha='right')
    ax1.set_ylabel('Transcript Abundance (nCPM)')
    ax1.set_title('A. Single-Cell NaV Stoichiometry (HPA)', fontweight='bold')
    ax1.legend(frameon=True, facecolor='white', framealpha=0.9)

    # Panel B: Lineage vulnerability response
    # SCN1A LOF produces -0.326 in interneurons vs -0.037 in pyramidal
    # SCN2A GOF produces +1.082 in pyramidal vs +0.131 in interneurons
    categories = ['Excitatory Pyramidal', 'Inhibitory Interneurons']
    resp_scn2a_gof = [+1.082, +0.131]
    resp_scn1a_lof = [-0.037, -0.326]

    x2 = np.arange(len(categories))
    w2 = 0.35
    ax2.bar(x2 - w2/2, resp_scn2a_gof, width=w2, label='SCN2A GOF (GOF-3)', color='#d90429', edgecolor='black', lw=0.6)
    ax2.bar(x2 + w2/2, resp_scn1a_lof, width=w2, label='SCN1A LOF (Dravet)', color='#0077b6', edgecolor='black', lw=0.6)
    ax2.axhline(0, color='black', lw=0.8)

    ax2.set_xticks(x2)
    ax2.set_xticklabels(categories)
    ax2.set_ylabel('Excitability Perturbation Index (EPI_c)')
    ax2.set_title('B. Cell-Type Specific Vulnerability', fontweight='bold')
    ax2.legend(loc='upper right', frameon=True, facecolor='white', framealpha=0.9)

    fig.tight_layout()
    save_figure(fig, 'Figure4')


def generate_figure5():
    """Figure 5: Modifier gene epistatic buffering in Dravet syndrome."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.2))

    # Panel A: 2D contour plot of PDI_mod
    g_ratios = np.linspace(0.4, 2.5, 40)
    ca_ratios = np.linspace(0.4, 1.5, 40)
    PDI_grid = np.zeros((len(ca_ratios), len(g_ratios)))

    from biophys import gabaergic_compensation_factor, modified_phenotypic_divergence_index
    for i, ca in enumerate(ca_ratios):
        for j, g in enumerate(g_ratios):
            k = gabaergic_compensation_factor(g, ca)
            pmod, _ = modified_phenotypic_divergence_index(-0.037, -0.326, k)
            PDI_grid[i, j] = pmod

    G_mesh, CA_mesh = np.meshgrid(g_ratios, ca_ratios)
    cp = ax1.contourf(G_mesh, CA_mesh, PDI_grid, levels=14, cmap='coolwarm')
    cbar = fig.colorbar(cp, ax=ax1)
    cbar.set_label('Modified PDI (PDI_mod)')

    # Add seizure threshold contour (PDI = +0.15)
    cs = ax1.contour(G_mesh, CA_mesh, PDI_grid, levels=[0.15], colors=['black'], linestyles=['dashed'], lw=[1.2])
    ax1.clabel(cs, inline=True, fontsize=7, fmt='Seizure Boundary (+0.15)')

    # Project strains
    strains = [
        ('B6', 0.50, 1.25, '#7209b7'),
        ('B6_ref', 1.00, 1.00, '#3a0ca3'),
        ('F1', 1.50, 0.85, '#f72585'),
        ('129S6', 2.00, 0.70, '#4cc9f0'),
        ('129+KD', 2.00, 0.50, '#38b000')
    ]
    for name, gx, cax, col in strains:
        ax1.scatter(gx, cax, color=col, s=40, edgecolors='black', zorder=5)
        ax1.text(gx + 0.05, cax, name, fontsize=7.5, fontweight='bold', zorder=6)

    ax1.set_xlabel('Relative Gabra2 Expression (E / E_ref)')
    ax1.set_ylabel('Relative Cacna1g Expression (E / E_ref)')
    ax1.set_title('A. Epistatic Modifier Phase Space', fontweight='bold')

    # Panel B: Strain barplot of PDI_mod
    strain_names = ['B6 (Severe)', 'B6 Ref', 'F1 Hybrid', '129S6 (Resistant)', '129 + CaV KD']
    pdi_mod_vals = [+0.368, +0.212, -0.043, -0.284, -0.331]
    bar_colors = ['#d90429', '#ef233c', '#ffb703', '#2a9d8f', '#1b4332']

    bars = ax2.bar(strain_names, pdi_mod_vals, color=bar_colors, edgecolor='black', lw=0.6)
    ax2.axhline(0.15, color='red', linestyle=':', label='Seizure Threshold (+0.15)')
    ax2.axhline(-0.15, color='blue', linestyle=':', label='ASD Threshold (-0.15)')
    ax2.axhline(0.00, color='black', lw=0.6)

    ax2.set_xticklabels(strain_names, rotation=25, ha='right')
    ax2.set_ylabel('Modified PDI Score (PDI_mod)')
    ax2.set_title('B. Genetic Background Buffering', fontweight='bold')
    ax2.legend(loc='upper right', fontsize=7)

    fig.tight_layout()
    save_figure(fig, 'Figure5')


def generate_figureS1():
    """Figure S1: Boltzmann Gating Curves and Persistent Activation."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.0))

    V = np.linspace(-100, 40, 500)
    m_wt = boltzmann_act(V, V_HALF_ACT_WT, K_ACT_WT)
    h_wt = boltzmann_inact(V, V_HALF_INACT_WT, K_INACT_WT)
    p_wt = boltzmann_p(V)

    m_gof = boltzmann_act(V, V_HALF_ACT_WT - 10.0, K_ACT_WT)
    m_lof = boltzmann_act(V, V_HALF_ACT_WT + 8.0, K_ACT_WT)

    # Panel A: Gating curves
    ax1.plot(V, m_wt, 'k-', label=r'$m_\infty$ WT (-35 mV)', lw=1.5)
    ax1.plot(V, h_wt, 'k--', label=r'$h_\infty$ WT (-65 mV)', lw=1.5)
    ax1.plot(V, m_gof, 'r-', label=r'$m_\infty$ GOF (-45 mV)', lw=1.2)
    ax1.plot(V, m_lof, 'b-', label=r'$m_\infty$ LOF (-27 mV)', lw=1.2)
    ax1.plot(V, p_wt, 'm:', label=r'$p_\infty$ Persistent (-48 mV)', lw=1.5)

    ax1.set_xlabel('Membrane Potential (mV)')
    ax1.set_ylabel('Steady-State Open Probability')
    ax1.set_title('A. Boltzmann Gating Dynamics', fontweight='bold')
    ax1.legend(loc='center left', fontsize=6.5)

    # Panel B: Window current
    win_wt = m_wt * h_wt
    win_gof = m_gof * h_wt
    ax2.fill_between(V, win_wt, color='gray', alpha=0.3, label='WT Window')
    ax2.fill_between(V, win_gof, color='red', alpha=0.25, label='GOF Window (+Shifted)')
    ax2.plot(V, win_wt, 'k-', lw=1.2)
    ax2.plot(V, win_gof, 'r-', lw=1.2)

    ax2.set_xlim(-80, -20)
    ax2.set_xlabel('Membrane Potential (mV)')
    ax2.set_ylabel('Overlap Product (m_inf * h_inf)')
    ax2.set_title('B. Sub-threshold Window Current', fontweight='bold')
    ax2.legend(loc='upper right', fontsize=7.5)

    fig.tight_layout()
    save_figure(fig, 'FigureS1')


def main():
    print("=" * 70)
    print(" Step 07: Rendering Publication-Quality Figures (PDF & 300-dpi PNG)")
    print("=" * 70)
    set_nature_style()

    generate_figure1()
    generate_figure2()
    generate_figure3()
    generate_figure4()
    generate_figure5()
    generate_figureS1()

    print("\n[OK] All figures successfully rendered in figures/ directory.")


if __name__ == '__main__':
    main()
