"""
biophys.py - Core mathematical and biophysical library for the sodium channelopathy model.
Implements Equations 1 through 11 of the manuscript:
"Cell-type-specific biophysical modeling reveals modifier-dependent phenotypic
divergence in sodium channelopathies: a computational framework for the
autism-epilepsy spectrum"

Authors: Lenin González-Paz, Ysaías J. Alvarado, et al. (2026)
License: MIT
"""

import numpy as np
from scipy.integrate import solve_ivp

# Default physical and physiological constants
C_M = 1.0          # uF/cm^2 (Membrane capacitance)
G_NA_BAR = 120.0   # mS/cm^2 (Maximal transient sodium conductance)
G_K_BAR = 36.0     # mS/cm^2 (Maximal delayed rectifier potassium conductance)
G_L_BAR = 0.3      # mS/cm^2 (Passive membrane leak conductance)

E_NA = 55.0        # mV (Sodium reversal potential)
E_K = -90.0        # mV (Potassium reversal potential)
E_L = -70.0        # mV (Leak reversal potential)

# Canonical wild-type NaV1.2 gating parameters
V_HALF_ACT_WT = -35.0     # mV (Half-activation midpoint)
K_ACT_WT = 5.5            # mV (Activation slope factor)
V_HALF_INACT_WT = -65.0   # mV (Half-inactivation midpoint)
K_INACT_WT = 6.5          # mV (Inactivation slope factor)

# Persistent sodium current gating parameters
V_HALF_P = -48.0          # mV (Persistent activation midpoint)
K_P = 5.0                 # mV (Persistent slope factor)
F_NAP_WT = 0.01           # 1% persistent fraction under WT conditions

# Cell-type specific subunit weights (Spratt et al. 2019, Hu et al. 2009, Ogiwara et al. 2007)
WEIGHTS_EXC = {'SCN2A': 0.55, 'SCN8A': 0.35, 'SCN1A': 0.10}
WEIGHTS_INH = {'SCN1A': 0.65, 'SCN8A': 0.25, 'SCN2A': 0.10}

# Wild-type reference electrophysiological baselines
F_EXC_WT = 38.5      # Hz (Firing frequency at 15 uA/cm^2 somatic injection)
I_RHEO_EXC_WT = 4.20 # uA/cm^2 (Rheobase threshold)
F_INH_WT = 62.4      # Hz (Firing frequency at 15 uA/cm^2 somatic injection)
I_RHEO_INH_WT = 5.80 # uA/cm^2 (Rheobase threshold)


def boltzmann_act(V, V_half=V_HALF_ACT_WT, k=K_ACT_WT):
    """Eq. 3a: Steady-state activation m_inf(V)."""
    return 1.0 / (1.0 + np.exp(-(V - V_half) / k))


def boltzmann_inact(V, V_half=V_HALF_INACT_WT, k=K_INACT_WT):
    """Eq. 3b: Steady-state fast inactivation h_inf(V)."""
    return 1.0 / (1.0 + np.exp((V - V_half) / k))


def boltzmann_p(V, V_half=V_HALF_P, k=K_P):
    """Eq. 4: Steady-state persistent sodium activation p_inf(V)."""
    return 1.0 / (1.0 + np.exp(-(V - V_half) / k))


def tau_m(V, V_half=V_HALF_ACT_WT, k=K_ACT_WT):
    """Activation time constant tau_m (ms)."""
    arg = np.clip((V - V_half) / (2.0 * k), -20.0, 20.0)
    return 0.05 + 0.45 / np.cosh(arg)


def tau_h(V, V_half=V_HALF_INACT_WT, k=K_INACT_WT):
    """Fast inactivation time constant tau_h (ms)."""
    arg = np.clip((V - V_half) / (2.0 * k), -20.0, 20.0)
    return 0.50 + 7.50 / np.cosh(arg)


def alpha_n(V):
    """Delayed rectifier potassium alpha_n rate (ms^-1)."""
    v = V + 65.0
    denom = np.exp((10.0 - v) / 10.0) - 1.0
    if np.abs(denom) < 1e-7:
        return 0.1
    return 0.01 * (10.0 - v) / denom


def beta_n(V):
    """Delayed rectifier potassium beta_n rate (ms^-1)."""
    v = V + 65.0
    return 0.125 * np.exp(-v / 80.0)


def n_inf(V):
    """Potassium steady-state activation."""
    an = alpha_n(V)
    bn = beta_n(V)
    return an / (an + bn)


def tau_n(V):
    """Potassium activation time constant (ms)."""
    an = alpha_n(V)
    bn = beta_n(V)
    return 1.0 / (an + bn)


def hh_derivatives(t, y, g_Na, g_K, g_L, E_Na, E_K, E_L, C_m, I_inj,
                   V_half_act, k_act, V_half_inact, k_inact, f_NaP):
    """
    Evaluates system of ODEs for membrane potential and gating variables (Eqs. 1-4).
    y = [V, m, h, n]
    """
    V, m, h, n = y

    # Currents
    I_NaT = (1.0 - f_NaP) * g_Na * (m**3) * h * (V - E_Na)
    I_NaP = f_NaP * g_Na * boltzmann_p(V) * (V - E_Na)
    I_Na = I_NaT + I_NaP
    I_K = g_K * (n**4) * (V - E_K)
    I_L = g_L * (V - E_L)

    # dV/dt (Eq. 1)
    dVdt = (-I_Na - I_K - I_L + I_inj) / C_m

    # Gating dynamics
    minf = boltzmann_act(V, V_half_act, k_act)
    tm = tau_m(V, V_half_act, k_act)
    dmdt = (minf - m) / tm

    hinf = boltzmann_inact(V, V_half_inact, k_inact)
    th = tau_h(V, V_half_inact, k_inact)
    dhdt = (hinf - h) / th

    ninf_val = n_inf(V)
    tn = tau_n(V)
    dndt = (ninf_val - n) / tn

    return [dVdt, dmdt, dhdt, dndt]


def simulate_neuron(g_Na=G_NA_BAR, g_K=G_K_BAR, g_L=G_L_BAR,
                    E_Na=E_NA, E_K=E_K, E_L=E_L, C_m=C_M,
                    I_inj=15.0, duration=1000.0, dt=0.025,
                    V_half_act=V_HALF_ACT_WT, k_act=K_ACT_WT,
                    V_half_inact=V_HALF_INACT_WT, k_inact=K_INACT_WT,
                    f_NaP=F_NAP_WT):
    """
    Runs adaptive integration of single neuron. Returns time, voltage, and firing frequency.
    """
    V0 = -70.0
    m0 = boltzmann_act(V0, V_half_act, k_act)
    h0 = boltzmann_inact(V0, V_half_inact, k_inact)
    n0 = n_inf(V0)
    y0 = [V0, m0, h0, n0]

    t_eval = np.arange(0, duration, dt)
    sol = solve_ivp(
        fun=hh_derivatives,
        t_span=[0, duration],
        y0=y0,
        t_eval=t_eval,
        method='RK45',
        args=(g_Na, g_K, g_L, E_Na, E_K, E_L, C_m, I_inj,
              V_half_act, k_act, V_half_inact, k_inact, f_NaP),
        rtol=1e-5, atol=1e-6
    )

    t = sol.t
    V = sol.y[0]

    # Calculate firing frequency in the last 500 ms (steady state)
    t_start = duration - 500.0
    idx_start = np.searchsorted(t, t_start)
    V_sub = V[idx_start:]

    # Count upward zero-crossings
    crossings = np.where((V_sub[:-1] < 0.0) & (V_sub[1:] >= 0.0))[0]
    n_spikes = len(crossings)
    f_hz = n_spikes / (0.5)  # spikes per 0.5 sec -> Hz

    return t, V, f_hz


def find_rheobase(g_Na=G_NA_BAR, g_K=G_K_BAR, g_L=G_L_BAR,
                  V_half_act=V_HALF_ACT_WT, k_act=K_ACT_WT,
                  V_half_inact=V_HALF_INACT_WT, k_inact=K_INACT_WT,
                  f_NaP=F_NAP_WT, I_min=0.0, I_max=15.0, tol=0.02):
    """
    Bisection algorithm to identify rheobase current (uA/cm^2).
    """
    low = I_min
    high = I_max

    for _ in range(20):
        mid = (low + high) / 2.0
        _, _, freq = simulate_neuron(
            g_Na=g_Na, g_K=g_K, g_L=g_L,
            I_inj=mid, duration=200.0, dt=0.05,
            V_half_act=V_half_act, k_act=k_act,
            V_half_inact=V_half_inact, k_inact=k_inact,
            f_NaP=f_NaP
        )
        if freq > 0.0:
            high = mid
        else:
            low = mid
        if (high - low) < tol:
            break

    return (low + high) / 2.0


def stoichiometric_conductance(E_norm_dict, weights_dict, alpha_dict, g_base=G_NA_BAR):
    """
    Eq. 6: Computes cell-type specific conductance.
    g_Na,c = g_base * sum_i( w_i,c * E_norm,i,c * alpha_i )
    """
    g_eff = 0.0
    for gene, w in weights_dict.items():
        e = E_norm_dict.get(gene, 1.0)
        a = alpha_dict.get(gene, 1.0)
        g_eff += w * e * a
    return g_base * g_eff


def excitability_perturbation_index(f_mut, I_rheo_mut, f_wt, I_rheo_wt):
    """
    Eq. 7: Excitability Perturbation Index (EPI_c)
    EPI_c = (f_mut - f_wt)/f_wt - (I_rheo_mut - I_rheo_wt)/I_rheo_wt
    """
    delta_f = (f_mut - f_wt) / f_wt
    delta_rheo = (I_rheo_mut - I_rheo_wt) / I_rheo_wt
    return delta_f - delta_rheo


def phenotypic_divergence_index(EPI_exc, EPI_inh):
    """
    Eq. 8: Phenotypic Divergence Index (PDI)
    PDI = (EPI_exc - EPI_inh) / (1 + |EPI_exc| + |EPI_inh|)
    """
    numerator = EPI_exc - EPI_inh
    denominator = 1.0 + np.abs(EPI_exc) + np.abs(EPI_inh)
    return numerator / denominator


def gabaergic_compensation_factor(E_Gabra2_ratio, E_Cacna1g_ratio=1.0,
                                   gamma_G=0.85, delta_Ca=0.40):
    """
    Eq. 9: Postsynaptic GABAergic modifier compensation factor kappa_GABA.
    kappa_GABA = (E_Gabra2 / E_Gabra2_ref)^gamma_G * [ 1 + delta_Ca * (1 - E_Cacna1g / E_Cacna1g_ref) ]
    """
    gaba_term = (E_Gabra2_ratio) ** gamma_G
    ca_term = 1.0 + delta_Ca * (1.0 - E_Cacna1g_ratio)
    return gaba_term * ca_term


def modified_phenotypic_divergence_index(EPI_exc, EPI_inh, kappa_GABA):
    """
    Eqs. 10-11: Background-modified PDI (PDI_mod)
    EPI_inh_eff = (1 + EPI_inh) * kappa_GABA - 1
    PDI_mod = (EPI_exc - EPI_inh_eff) / (1 + |EPI_exc| + |EPI_inh_eff|)
    """
    EPI_inh_eff = (1.0 + EPI_inh) * kappa_GABA - 1.0
    numerator = EPI_exc - EPI_inh_eff
    denominator = 1.0 + np.abs(EPI_exc) + np.abs(EPI_inh_eff)
    return numerator / denominator, EPI_inh_eff
