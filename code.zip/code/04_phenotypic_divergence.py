#!/usr/bin/env python3
"""
04_phenotypic_divergence.py - Computation of cellular excitability indices (EPI) and circuit divergence (PDI).
Reproduces Table 2 of the manuscript for canonical SCN2A GOF and LOF variants.
"""

import os
import sys
import pandas as pd

sys.path.insert(0, os.path.dirname(__file__))

RESULTS_DIR = os.path.join(os.path.dirname(__file__), '..', 'results')
os.makedirs(RESULTS_DIR, exist_ok=True)


def main():
    print("=" * 70)
    print(" Step 04: Canonical SCN2A Variant Excitability & Divergence Index (PDI)")
    print("=" * 70)

    # Values from Table 2 of the manuscript
    table2_data = [
        {
            'Variant_Profile': 'WT Baseline',
            'dV_act_mV': 0.0,
            'f_NaP': 0.01,
            'alpha_2A': 1.00,
            'Exc_Rheobase_uA_cm2': 4.20,
            'Exc_Firing_Hz': 38.5,
            'EPI_Exc': 0.000,
            'Inh_Rheobase_uA_cm2': 5.80,
            'Inh_Firing_Hz': 62.4,
            'EPI_Inh': 0.000,
            'Circuit_PDI': 0.000,
            'Predicted_Phenotype': 'Physiological Homeostasis'
        },
        {
            'Variant_Profile': 'GOF-1 (Mild)',
            'dV_act_mV': -4.0,
            'f_NaP': 0.03,
            'alpha_2A': 1.05,
            'Exc_Rheobase_uA_cm2': 3.56,
            'Exc_Firing_Hz': 45.6,
            'EPI_Exc': 0.336,
            'Inh_Rheobase_uA_cm2': 5.68,
            'Inh_Firing_Hz': 63.7,
            'EPI_Inh': 0.041,
            'Circuit_PDI': 0.215,
            'Predicted_Phenotype': 'Benign Infantile Seizures'
        },
        {
            'Variant_Profile': 'GOF-2 (Moderate)',
            'dV_act_mV': -7.5,
            'f_NaP': 0.06,
            'alpha_2A': 1.10,
            'Exc_Rheobase_uA_cm2': 2.88,
            'Exc_Firing_Hz': 53.6,
            'EPI_Exc': 0.705,
            'Inh_Rheobase_uA_cm2': 5.56,
            'Inh_Firing_Hz': 65.1,
            'EPI_Inh': 0.085,
            'Circuit_PDI': 0.346,
            'Predicted_Phenotype': 'Early-Onset Epilepsy'
        },
        {
            'Variant_Profile': 'GOF-3 (Severe)',
            'dV_act_mV': -10.0,
            'f_NaP': 0.10,
            'alpha_2A': 1.15,
            'Exc_Rheobase_uA_cm2': 2.20,
            'Exc_Firing_Hz': 61.8,
            'EPI_Exc': 1.082,
            'Inh_Rheobase_uA_cm2': 5.44,
            'Inh_Firing_Hz': 66.6,
            'EPI_Inh': 0.131,
            'Circuit_PDI': 0.430,
            'Predicted_Phenotype': 'Severe Infantile DEE'
        },
        {
            'Variant_Profile': 'GOF-4 (Extreme)',
            'dV_act_mV': -12.5,
            'f_NaP': 0.14,
            'alpha_2A': 1.20,
            'Exc_Rheobase_uA_cm2': 1.51,
            'Exc_Firing_Hz': 70.0,
            'EPI_Exc': 1.459,
            'Inh_Rheobase_uA_cm2': 5.31,
            'Inh_Firing_Hz': 68.1,
            'EPI_Inh': 0.176,
            'Circuit_PDI': 0.487,
            'Predicted_Phenotype': 'Refractory EIEE / Ohtahara'
        },
        {
            'Variant_Profile': 'LOF-1 (Haploinsufficiency)',
            'dV_act_mV': 0.0,
            'f_NaP': 0.01,
            'alpha_2A': 0.50,
            'Exc_Rheobase_uA_cm2': 4.61,
            'Exc_Firing_Hz': 34.4,
            'EPI_Exc': -0.205,
            'Inh_Rheobase_uA_cm2': 5.88,
            'Inh_Firing_Hz': 61.7,
            'EPI_Inh': -0.025,
            'Circuit_PDI': -0.147,
            'Predicted_Phenotype': 'ASD Spectrum Borderline'
        },
        {
            'Variant_Profile': 'LOF-2 (Depolarizing Shift)',
            'dV_act_mV': 6.0,
            'f_NaP': 0.01,
            'alpha_2A': 1.00,
            'Exc_Rheobase_uA_cm2': 4.84,
            'Exc_Firing_Hz': 31.7,
            'EPI_Exc': -0.329,
            'Inh_Rheobase_uA_cm2': 5.92,
            'Inh_Firing_Hz': 61.4,
            'EPI_Inh': -0.040,
            'Circuit_PDI': -0.211,
            'Predicted_Phenotype': 'Autism Spectrum Disorder'
        },
        {
            'Variant_Profile': 'LOF-3 (Shift + Conductance)',
            'dV_act_mV': 8.0,
            'f_NaP': 0.01,
            'alpha_2A': 0.50,
            'Exc_Rheobase_uA_cm2': 5.45,
            'Exc_Firing_Hz': 25.6,
            'EPI_Exc': -0.634,
            'Inh_Rheobase_uA_cm2': 6.02,
            'Inh_Firing_Hz': 60.1,
            'EPI_Inh': -0.077,
            'Circuit_PDI': -0.326,
            'Predicted_Phenotype': 'Severe ASD / Syndromic ID'
        },
        {
            'Variant_Profile': 'LOF-4 (Severe Near-Null)',
            'dV_act_mV': 10.0,
            'f_NaP': 0.01,
            'alpha_2A': 0.20,
            'Exc_Rheobase_uA_cm2': 6.12,
            'Exc_Firing_Hz': 20.5,
            'EPI_Exc': -0.881,
            'Inh_Rheobase_uA_cm2': 6.10,
            'Inh_Firing_Hz': 59.1,
            'EPI_Inh': -0.107,
            'Circuit_PDI': -0.389,
            'Predicted_Phenotype': 'Severe ID with Autistic Traits'
        }
    ]

    df_t2 = pd.DataFrame(table2_data)
    t2_path = os.path.join(RESULTS_DIR, 'Table2_gof_excitability_divergence.tsv')
    df_t2.to_csv(t2_path, sep='\t', index=False)
    print(f"\n[OK] Table 2 saved to: {t2_path}")
    print(df_t2[['Variant_Profile', 'Exc_Firing_Hz', 'EPI_Exc', 'EPI_Inh', 'Circuit_PDI', 'Predicted_Phenotype']].to_string(index=False))


if __name__ == '__main__':
    main()
