#!/usr/bin/env python3
"""
08_supplementary_tables.py - Assembles developmental BrainSpan trajectories (Table 6)
and creates the Supplementary Data workbook (Excel/TSV).
"""

import os
import sys
import pandas as pd

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')
RAW_DIR = os.path.join(DATA_DIR, 'raw')
RESULTS_DIR = os.path.join(os.path.dirname(__file__), '..', 'results')
os.makedirs(RESULTS_DIR, exist_ok=True)


def main():
    print("=" * 70)
    print(" Step 08: Ontogenetic Development Trajectory (Table 6) & Supplementary Data")
    print("=" * 70)

    # 1. Table 6: BrainSpan ontogeny
    brainspan_file = os.path.join(RAW_DIR, 'brainspan_developmental_rpkm.csv')
    df_bs = pd.read_csv(brainspan_file)

    subcellular_info = [
        'NaV1.2 (Soma + AIS)',
        'NaV1.2 dominant',
        'NaV1.2 peak; NaV1.6 rising',
        'NaV1.6 at distal AIS; NaV1.2 proximal',
        'Mature compartmentalization'
    ]
    interneuron_status = [
        'Immature / Migrating',
        'Immature / Forming synapses',
        'Parvalbumin low / Initial firing',
        'Parvalbumin mature / Fast-spiking',
        'Fully mature fast-spiking'
    ]
    vuln_gof = [
        'Latent / Pre-synaptic',
        'High (Emerging EIEE)',
        'Peak Vulnerability (<3 mos)',
        'Declining / ASD emergence',
        'Low seizure risk / Stable ASD'
    ]
    vuln_lof = [
        'Silent',
        'Silent',
        'Latent / Sub-clinical',
        'Peak Vulnerability (6-12 mos)',
        'Chronic Dravet / Resistant'
    ]

    df_bs['Primary_Subcellular_NaV'] = subcellular_info
    df_bs['Interneuron_Maturation_Status'] = interneuron_status
    df_bs['Vulnerability_Window_SCN2A_GOF'] = vuln_gof
    df_bs['Vulnerability_Window_SCN1A_LOF'] = vuln_lof

    t6_path = os.path.join(RESULTS_DIR, 'Table6_ontogenetic_brainspan.tsv')
    df_bs.to_csv(t6_path, sep='\t', index=False)
    print(f"\n[OK] Table 6 saved to: {t6_path}")
    print(df_bs[['Stage', 'Age', 'SCN1A_mean', 'SCN2A_mean', 'SCN8A_mean', 'Vulnerability_Window_SCN2A_GOF', 'Vulnerability_Window_SCN1A_LOF']].to_string(index=False))

    # 2. Assemble Supplementary Data Workbook (Excel)
    excel_path = os.path.join(RESULTS_DIR, 'Supplementary_Data.xlsx')
    try:
        with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
            # Table 1
            t1_file = os.path.join(RESULTS_DIR, 'Table1_regional_expression.tsv')
            if os.path.exists(t1_file):
                pd.read_csv(t1_file, sep='\t').to_excel(writer, sheet_name='Table_S1_Regional', index=False)

            # Table 2
            t2_file = os.path.join(RESULTS_DIR, 'Table2_gof_excitability_divergence.tsv')
            if os.path.exists(t2_file):
                pd.read_csv(t2_file, sep='\t').to_excel(writer, sheet_name='Table_S2_SCN2A_Variants', index=False)

            # Table 3
            t3_file = os.path.join(RESULTS_DIR, 'Table3_2d_parametric_landscape_pdi.tsv')
            if os.path.exists(t3_file):
                pd.read_csv(t3_file, sep='\t').to_excel(writer, sheet_name='Table_S3_PDI_Landscape', index=False)

            # Table 4
            t4_file = os.path.join(RESULTS_DIR, 'Table4_single_cell_excitability.tsv')
            if os.path.exists(t4_file):
                pd.read_csv(t4_file, sep='\t').to_excel(writer, sheet_name='Table_S4_Single_Cell', index=False)

            # Table 5
            t5_file = os.path.join(RESULTS_DIR, 'Table5_modifier_buffering_dravet.tsv')
            if os.path.exists(t5_file):
                pd.read_csv(t5_file, sep='\t').to_excel(writer, sheet_name='Table_S5_Modifier_Epistasis', index=False)

            # Table 6
            df_bs.to_excel(writer, sheet_name='Table_S6_Ontogeny', index=False)

            # Table 7
            t7_file = os.path.join(RESULTS_DIR, 'Table7_sobol_sensitivity.tsv')
            if os.path.exists(t7_file):
                pd.read_csv(t7_file, sep='\t').to_excel(writer, sheet_name='Table_S7_Sobol_Sensitivity', index=False)

        print(f"[OK] Supplementary Data workbook generated: {excel_path}")
    except Exception as e:
        print(f"[INFO] Excel export skipped ({e}); all TSV tables remain fully accessible in results/.")


if __name__ == '__main__':
    main()
